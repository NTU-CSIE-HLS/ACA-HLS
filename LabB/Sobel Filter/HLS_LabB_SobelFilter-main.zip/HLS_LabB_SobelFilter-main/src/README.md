# HLS_LabB_SobelFilter
XAPP890 - Sobel Filter
* Sobel and Feldman presented the idea of an "Isotropic 3x3 Image Gradient Operator" at a talk at SAIL in 1968
* Used in image processing and computer vision
* Edge detection algorithms where it creates an image emphasising edges
