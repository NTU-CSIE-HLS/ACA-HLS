#include "common.hpp"

void cpu (instr_t instruction_memory_i[INSTR_MEM_SIZE], data_t final_register_file_o[REGISTER_NUM]);
