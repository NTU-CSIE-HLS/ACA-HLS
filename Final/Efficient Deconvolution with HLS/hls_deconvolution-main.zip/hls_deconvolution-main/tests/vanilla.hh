#ifndef VANILLA_HH__
#define VANILLA_HH__

template <int Stride, int Padding,
		  class Tp,
		  int OutHeight, int OutWidth, int OutChannels,
		  int InHeight, int InWidth, int InChannels,
		  int KerSize>
void vanilla_deconvolution(Tp (&out)[OutHeight][OutWidth][OutChannels],
						   const Tp (&in)[InHeight][InWidth][InChannels],
						   const Tp (&ker)[KerSize][KerSize][OutChannels][InChannels])
{
	for (int ih{}; ih != InHeight; ++ih) {
		for (int kh{}; kh != KerSize; ++kh) {
			const auto oh = Stride * ih + kh - Padding;
			if (oh < 0 || oh >= OutHeight) {
				continue;
			}

			for (int iw{}; iw != InWidth; ++iw) {
				for (int kw{}; kw != KerSize; ++kw) {
					const auto ow = Stride * iw + kw - Padding;
					if (ow < 0 || ow >= OutWidth) {
						continue;
					}

					for (int oc{}; oc != OutChannels; ++oc) {
						for (int ic{}; ic != InChannels; ++ic) {
							out[oh][ow][oc] += in[ih][iw][ic] * ker[kh][kw][oc][ic];
						}
					}
				}
			}
		}
	}
}

#endif // VANILLA_HH__