/*===============================================================*/
/*                                                               */
/*                       check_result.cpp                        */
/*                                                               */
/*      Software evaluation of training and test error rate      */
/*                                                               */
/*===============================================================*/

#include <cstdio>
#include <string>
#include <cmath>
#include <fstream>

#include "typedefs.h"
#include "../imageLib/imageLib.h"
void gen_output(velocity_t output[MAX_HEIGHT][MAX_WIDTH], std::string outFile)
{
	CFloatImage outFlow(MAX_WIDTH, MAX_HEIGHT, 2);
	  for (int i = 0; i < MAX_HEIGHT; i++)
	  {
	    for (int j = 0; j < MAX_WIDTH; j++)
	    {
	      double out_x = output[i][j].x.to_double();
	      double out_y = output[i][j].y.to_double();

	      if (out_x * out_x + out_y * out_y > 25.0)
	      {
	        outFlow.Pixel(j, i, 0) = 1e10;
	        outFlow.Pixel(j, i, 1) = 1e10;
	      }
	      else
	      {
	        outFlow.Pixel(j, i, 0) = out_x;
	        outFlow.Pixel(j, i, 1) = out_y;
	      }
	    }
	  }
//	  std::cout << "Writing Flow File!" << std::endl;
	  WriteFlowFile(outFlow, outFile.c_str());
}

void check_results(velocity_t output[MAX_HEIGHT][MAX_WIDTH], CFloatImage refFlow, std::string outFile)
{
  // copy the output into the float image
  CFloatImage outFlow(MAX_WIDTH, MAX_HEIGHT, 2);
  for (int i = 0; i < MAX_HEIGHT; i++) 
  {
    for (int j = 0; j < MAX_WIDTH; j++) 
    {
      double out_x = output[i][j].x.to_double();
      double out_y = output[i][j].y.to_double();

      if (out_x * out_x + out_y * out_y > 25.0) 
      {
        outFlow.Pixel(j, i, 0) = 1e10;
        outFlow.Pixel(j, i, 1) = 1e10;
      } 
      else 
      {
        outFlow.Pixel(j, i, 0) = out_x;
        outFlow.Pixel(j, i, 1) = out_y;
      }
    }
  }
//  std::cout << "Writing Flow File!" << std::endl;
  WriteFlowFile(outFlow, outFile.c_str());

//  std::cout << "Error Rate!" << std::endl;
  double accum_error = 0;
  int num_pix = 0;
  for (int i = 0; i < MAX_HEIGHT; i++) 
  {
    for (int j = 0; j < MAX_WIDTH; j++) 
    {
      double out_x = outFlow.Pixel(j, i, 0);
      double out_y = outFlow.Pixel(j, i, 1);

      if (unknown_flow(out_x, out_y)) continue;

      double out_deg = atan2(-out_y, -out_x) * 180.0 / M_PI;
      double ref_x = refFlow.Pixel(j, i, 0);
      double ref_y = refFlow.Pixel(j, i, 1);
      double ref_deg = atan2(-ref_y, -ref_x) * 180.0 / M_PI;

      // Normalize error to [-180, 180]
      double error = out_deg - ref_deg;
      while (error < -180) error += 360;
      while (error > 180) error -= 360;

      accum_error += fabs(error);
      num_pix++;
    }
  }


  double avg_error = accum_error / num_pix;
  std::ofstream ofile;
  ofile.open("output.txt");
  if (ofile.is_open())
  {
    ofile << "Average error: " << avg_error << " degrees" << std::endl;
    ofile.close();
  }
  else
  {
//    std::cout << "Failed to create output file!" << std::endl;
  }

}
