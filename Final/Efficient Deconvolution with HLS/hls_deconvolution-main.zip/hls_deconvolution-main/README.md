# Efficient Deconvolution with HLS

## Introduction

We are 廖晨皓(team leader) and 許國讚 from team 6 of course CSIE5059, National Taiwan University, 2021 spring.
This is our final project.

- Final project proposal [slides](https://github.com/learningstud/hls_deconvolution/files/6721084/Guideline_for_Github_Submission.pdf)
- GitHub submission [guideline](https://github.com/learningstud/hls_deconvolution/files/6721085/Final_Project_Proposal.pdf)
- Reference [paper](https://arxiv.org/pdf/1705.02583.pdf): *A Design Methodology for Efficient Implementation of Deconvolutional Neural Networks on an FPGA*
- Vitis HLS 2021.1 [online manual](https://www.xilinx.com/html_docs/xilinx2021_1/vitis_doc/gnq1597858079367.html)
- NN quantization algorithms by [distiller](https://intellabs.github.io/distiller/algo_quantization.html).

## Major Optimizations

- Highlight area of optimization, e.g. loop unrolling, pipeline, array partition optimization
- Result as compare with the original

## Folder structure

- `README.md`; overview of the project.
- `LICENSE`; license file, we use MIT License.
- `build/`; build scripts -- bitstream.
- `docs/`; documentation files -- ppt, pdf, md.
- `src/`; source files, include kernel, and host code, cpp, hpp, other include files.
- `data/`; data files used in the project, include input test data and output result data.
- `impl_result/`; implementation result files, include.
- `tests/`; automated tests.

## Build Setup – allow rebuilding the result

- Environment variables settings, e.g. PATH
- Tool versions
- Steps to build/download test data, configuration
- Build FPGA bitstream generation

## Run test

- Unit test
- Integration test
