# Digit Recognition with k-NN
The source is taken from Lab 2 of ECE5775 at Cornell

To reproduce the result on Windows (There are some issues with `strtoul` in the main on Windows, so it's changed to `strtoull`)
```
$ hls_vivado -i
$ source run.tcl
```
or on Linux
```
$ make
```
