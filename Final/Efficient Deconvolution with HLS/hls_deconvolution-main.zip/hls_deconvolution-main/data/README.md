# data/

- Data files used in the project, include input test data and output result data.
- Describes where data came from.
