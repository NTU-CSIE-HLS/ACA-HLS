#ifndef __ENCRYPT_H__
#define __ENCRYPT_H__

#include "ap_int.h"

using namespace std;

void encrypt(ap_uint<128>*, ap_uint<64>*);

#endif

