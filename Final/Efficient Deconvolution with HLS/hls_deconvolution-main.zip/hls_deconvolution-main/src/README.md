# src/ -- design sources

- Design source files, include host & kernel codes
- It may contain original code from open source or the codes before optimization is applied.
- Folder host/ -- it is the host code
    - It can be simply a kernel testing code
    - Or application program
- Folder kernel_opt1 - kernel code with a specific optimization opt1
    - Use in-line pragma
    - Use different folder for different kernel optimization strategy, e.g. different pragma or code restructure. 
