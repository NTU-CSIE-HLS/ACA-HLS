# Vivado 2020.2 Block Design

## Create Project

- RTL Project ==一定要勾 vitis 那個==
- `xc7z020clg400-1`（我沒有板子可以選）

## Create Block Design

- `Settings` -> `IP` -> `Repository` 加入 `cpu.zip` unzip 之後的資料夾
- 加入 `cpu`、`ZYNQ7 Processing System`
- `Run Block Automation`、`Run Connection Automation`

![block_design](https://i.imgur.com/yON0NBA.png)

## Create HDL wrapper

## Generate Bitstream



