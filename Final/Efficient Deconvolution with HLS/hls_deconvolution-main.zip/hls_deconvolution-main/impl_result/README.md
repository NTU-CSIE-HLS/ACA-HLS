# impl_result/

- This is to cross-check the build process matches the original creator
work
- Collection of implementation result files, includes
    - Meta-data -- .hwh ...
    - Report files, including Vitis summary file, HLS synth report ...
