#ifndef DECONV_HH__
#define DECONV_HH__

// Channel-last or NHWC format: (batch, height, width, channels).
// This is what we call "bounded deconvolution".
#include "utils.hh"

template <int Stride, int Padding,
		  class Tp, // arithmetic type
		  int OutHeight, int OutWidth, int OutChannels,
		  int InHeight, int InWidth, int InChannels,
		  int KerSize>
void deconvolution(Tp (&out)[OutHeight][OutWidth][OutChannels],
				   const Tp (&in)[InHeight][InWidth][InChannels],
				   const Tp (&ker)[KerSize][KerSize][OutChannels][InChannels])
{
	constexpr auto I = ratio_ceiling(Padding - KerSize + 1, Stride);
	constexpr auto IH = min(InHeight, (OutHeight + 2 * Padding - KerSize) / Stride + 2);
	constexpr auto IW = min(InWidth, (OutWidth + 2 * Padding - KerSize) / Stride + 2);

	for (auto ih = I; ih < IH; ++ih) {
		for (auto kh = 0; kh != KerSize; ++kh) {
			const auto oh = Stride * ih + kh - Padding;
			if (oh < 0 || oh >= OutHeight) {
				continue;
			}

			for (auto iw = I; iw < IW; ++iw) {
				for (auto kw = 0; kw != KerSize; ++kw) {
					const auto ow = Stride * iw + kw - Padding;
					if (ow < 0 || ow >= OutWidth) {
						continue;
					}

					for (int oc{}; oc != OutChannels; ++oc) {
						for (int ic{}; ic != InChannels; ++ic) {
							out[oh][ow][oc] += in[ih][iw][ic] * ker[kh][kw][oc][ic];
						}
					}
				}
			}
		}
	}
}

#endif // DECONV_HH__
