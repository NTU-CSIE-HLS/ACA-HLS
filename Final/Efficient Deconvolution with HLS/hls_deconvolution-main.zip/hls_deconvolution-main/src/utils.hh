#ifndef UTILS_HH__
#define UTILS_HH__

template <class Tp> // integral types
constexpr Tp ratio_ceiling(Tp a, Tp b)
{
	if (a < 0 || b < 0) {
		return 0;
	}
	const auto ratio = a / b;
	return a % b == 0 ? ratio : ratio + 1;
}

template <class Tp> // arithmetic type
constexpr Tp min(Tp a, Tp b)
{
	return a < b ? a : b;
}

template <class Tp> // arithmetic type
constexpr Tp max(Tp a, Tp b)
{
	return a < b ? b : a;
}

template <class Tp> // arithmetic type
constexpr Tp relu(Tp a)
{
	return max(a, 0);
}

#endif // UTILS_HH__