# tests/

## tests/unit/ -- unit test

- If a design has multiple submodules, we recommend to test each sub-module separately
- Test code shall include expected result check
- The test includes software-emulation (c-sim), and hardware-emulation (co-sim)

## tests/integration/

- This is the full system level test,
    - Integrate all kernels/modules
    - Host program at application level
    - Using test data from a real application or open-source data if it is possible
    - Run with a real hardware (U50 or PYNQ-Z2)
    - Result is automatically tested for its correctness
- Three levels of test
    - Software-emulation (c-sim)
    - Hardware-emulation (co-sim)
    - Hardware – FPGA test with U50 or PYNQ-Z2
