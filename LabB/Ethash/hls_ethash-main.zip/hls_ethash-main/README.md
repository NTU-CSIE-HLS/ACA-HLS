# hls_ethash
This is the implementation of Ethash, which is the hashing algorithm for all Ethereum's Proof of Work, on Xilinx Alveo U200 acceleration board with Xilinx Vitis HLS tool.
