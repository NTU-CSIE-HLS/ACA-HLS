# doc/ -- Documentation files

- Presentation slides
- Reference papers
